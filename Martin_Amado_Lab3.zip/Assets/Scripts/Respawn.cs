﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Respawn : MonoBehaviour
{
    Rotationj move = new Rotationj();
    public GameObject prefab;
    public GameObject coin;
    private bool pause = false;
    public GameObject pauseScreen;

    Vector3 pos1 = new Vector3(-1.5f, 0.5f, -3.5f);
    Vector3 pos2 = new Vector3(-1.5f, 0.5f, 0.5f);
    Vector3 pos3 = new Vector3(2.75f, 0.5f, -3f);
    Vector3 pos4 = new Vector3(3.5f, 0.5f, 0.5f);

    Vector3 rot = new Vector3(90f, 0f, 0f);

    Vector3 originalPosition = new Vector3(-3.5f, 1.0f, -3.5f);


    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1.0f;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("return") && GameObject.FindWithTag("Player") == null)
            Restart();

        if (Input.GetKeyDown("escape"))
            changePause();






    }

    public void Restart()
    {
        if (GameObject.FindWithTag("Player") != null)
            Destroy(GameObject.FindWithTag("Player"));
        Instantiate(prefab, originalPosition, Quaternion.identity);
        move.DestroyAll();
        


        Instantiate(coin, pos1, Quaternion.Euler(rot));

        Instantiate(coin, pos2, Quaternion.Euler(rot));

        Instantiate(coin, pos3, Quaternion.Euler(rot));

        Instantiate(coin, pos4, Quaternion.Euler(rot));
    }

    public void changePause()
    {
        if (!pause)
        {
            pause = true;
            Time.timeScale = 0.0f;
            pauseScreen.SetActive(true);
        }
        else
        {
            pause = false;
            Time.timeScale = 1.0f;
            pauseScreen.SetActive(false);
        }
    }

    public void toMenu()
    {
        SceneManager.LoadScene(0);
    }

    public void toGame()
    {
        SceneManager.LoadScene(1);
    }
}
